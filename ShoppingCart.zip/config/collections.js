module.exports={
    PRODUCT_COLLECTION:'product',
    USER_C0LLECTION:'user',
    CART_COLLECTION:'cart',
    ORDER_COLLECTION:'order',
    ADMIN_COLLECTION:'admin'
}